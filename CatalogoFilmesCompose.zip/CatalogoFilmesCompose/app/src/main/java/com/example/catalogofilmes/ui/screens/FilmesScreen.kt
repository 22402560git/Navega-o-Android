package com.example.catalogofilmes.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.catalogofilmes.data.Filme
import com.example.catalogofilmes.viewmodel.FilmesViewModel

@Composable
fun FilmesScreen(
    viewModel: FilmesViewModel,
    onAbrirDetalhe: (Int) -> Unit
) {
    val filmes by viewModel.filmes.collectAsState()
    val favoritos by viewModel.favoritos.collectAsState()

    if (filmes.isEmpty()) {
        EstadoVazio("Nenhum filme disponível.")
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Catálogo de Filmes",
            style = MaterialTheme.typography.headlineMedium
        )

        LazyColumn(
            modifier = Modifier.padding(top = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(
                items = filmes,
                key = { it.id }
            ) { filme ->
                FilmeCard(
                    filme = filme,
                    favorito = filme.id in favoritos,
                    onFavorito = { viewModel.alternarFavorito(filme.id) },
                    onClick = { onAbrirDetalhe(filme.id) }
                )
            }
        }
    }
}

@Composable
fun FilmeCard(
    filme: Filme,
    favorito: Boolean,
    onFavorito: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = filme.titulo,
                    style = MaterialTheme.typography.titleLarge
                )
                Text("${filme.genero} • ${filme.ano}")
                Text("Nota: ${filme.nota}")
            }

            IconButton(onClick = onFavorito) {
                Icon(
                    imageVector = if (favorito) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = if (favorito) {
                        "Remover ${filme.titulo} dos favoritos"
                    } else {
                        "Adicionar ${filme.titulo} aos favoritos"
                    }
                )
            }
        }
    }
}

@Composable
fun EstadoVazio(mensagem: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = mensagem,
            style = MaterialTheme.typography.titleMedium
        )
    }
}
