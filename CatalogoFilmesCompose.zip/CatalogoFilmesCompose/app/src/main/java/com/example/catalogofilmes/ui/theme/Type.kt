package com.example.catalogofilmes.ui.theme

import androidx.compose.material3.Typography

val AppTypography = Typography()
