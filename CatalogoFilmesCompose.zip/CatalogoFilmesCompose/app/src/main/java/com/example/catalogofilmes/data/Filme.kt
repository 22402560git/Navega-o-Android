package com.example.catalogofilmes.data

data class Filme(
    val id: Int,
    val titulo: String,
    val genero: String,
    val ano: Int,
    val nota: Double,
    val descricao: String
)
