package com.example.catalogofilmes.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.findStartDestination
import androidx.navigation.toRoute
import com.example.catalogofilmes.ui.components.AppBottomBar
import com.example.catalogofilmes.ui.screens.DetalheScreen
import com.example.catalogofilmes.ui.screens.FavoritosScreen
import com.example.catalogofilmes.ui.screens.FilmesScreen
import com.example.catalogofilmes.ui.screens.LoginScreen
import com.example.catalogofilmes.ui.screens.PerfilScreen
import com.example.catalogofilmes.ui.screens.SplashScreen
import com.example.catalogofilmes.viewmodel.FilmesViewModel

@Composable
fun AppNavigation(viewModel: FilmesViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Splash
    ) {
        composable<Splash> {
            SplashScreen(
                onFinished = {
                    // A decisão de destino fica aqui, fora da Splash.
                    if (viewModel.isLoggedIn.value) {
                        navController.navigate(Main) {
                            popUpTo<Splash> { inclusive = true }
                        }
                    } else {
                        navController.navigate(Login) {
                            popUpTo<Splash> { inclusive = true }
                        }
                    }
                }
            )
        }

        composable<Login> {
            LoginScreen(
                onLogin = {
                    if (viewModel.login(it.first, it.second)) {
                        navController.navigate(Main) {
                            popUpTo<Login> { inclusive = true }
                        }
                    }
                }
            )
        }

        composable<Main> {
            MainScreen(
                navController = navController,
                viewModel = viewModel
            )
        }

        composable<Detalhe> { backStackEntry ->
            val rota = backStackEntry.toRoute<Detalhe>()
            DetalheScreen(
                filmeId = rota.filmeId,
                viewModel = viewModel,
                onVoltar = { navController.popBackStack() }
            )
        }
    }
}

@Composable
private fun MainScreen(
    navController: NavHostController,
    viewModel: FilmesViewModel
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destinoAtual = backStackEntry?.destination

    val abas = listOf(
        BottomTab(Filmes, "Filmes", Icons.Default.Home),
        BottomTab(Favoritos, "Favoritos", Icons.Default.Favorite),
        BottomTab(Perfil, "Perfil", Icons.Default.Person)
    )

    Scaffold(
        bottomBar = {
            AppBottomBar(
                abas = abas,
                destinoAtual = destinoAtual,
                onTabClick = { rota ->
                    navController.navigate(rota) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Filmes,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable<Filmes> {
                FilmesScreen(
                    viewModel = viewModel,
                    onAbrirDetalhe = { id ->
                        navController.navigate(Detalhe(id))
                    }
                )
            }

            composable<Favoritos> {
                FavoritosScreen(
                    viewModel = viewModel,
                    onAbrirDetalhe = { id ->
                        navController.navigate(Detalhe(id))
                    }
                )
            }

            composable<Perfil> {
                PerfilScreen(
                    viewModel = viewModel,
                    onSair = {
                        viewModel.logout()
                        navController.navigate(Login) {
                            popUpTo<Main> { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}

data class BottomTab(
    val route: AppRoute,
    val titulo: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
