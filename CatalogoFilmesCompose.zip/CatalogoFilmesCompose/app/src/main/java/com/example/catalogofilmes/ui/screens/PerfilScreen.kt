package com.example.catalogofilmes.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.catalogofilmes.viewmodel.FilmesViewModel

@Composable
fun PerfilScreen(
    viewModel: FilmesViewModel,
    onSair: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "Ícone do perfil"
        )

        Text(
            text = "Perfil",
            style = MaterialTheme.typography.headlineMedium
        )

        Text("Usuário conectado ao Catálogo de Filmes.")

        Button(onClick = onSair) {
            Text("Sair")
        }
    }
}
