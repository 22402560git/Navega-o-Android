package com.example.catalogofilmes.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.catalogofilmes.viewmodel.FilmesViewModel

@Composable
fun FavoritosScreen(
    viewModel: FilmesViewModel,
    onAbrirDetalhe: (Int) -> Unit
) {
    val filmes by viewModel.filmes.collectAsState()
    val favoritos by viewModel.favoritos.collectAsState()

    val lista = filmes.filter { it.id in favoritos }

    if (lista.isEmpty()) {
        EstadoVazio("Você ainda não possui filmes favoritos.")
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Meus Favoritos",
            style = MaterialTheme.typography.headlineMedium
        )

        LazyColumn(
            modifier = Modifier.padding(top = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(lista, key = { it.id }) { filme ->
                FilmeCard(
                    filme = filme,
                    favorito = true,
                    onFavorito = { viewModel.alternarFavorito(filme.id) },
                    onClick = { onAbrirDetalhe(filme.id) }
                )
            }
        }
    }
}
