package com.example.catalogofilmes.viewmodel

import androidx.lifecycle.ViewModel
import com.example.catalogofilmes.data.Filme
import com.example.catalogofilmes.data.FilmesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FilmesViewModel : ViewModel() {

    private val _filmes = MutableStateFlow(FilmesRepository.listarFilmes())
    val filmes: StateFlow<List<Filme>> = _filmes.asStateFlow()

    private val _favoritos = MutableStateFlow<Set<Int>>(emptySet())
    val favoritos: StateFlow<Set<Int>> = _favoritos.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    fun login(email: String, senha: String): Boolean {
        if (email.isBlank() || senha.isBlank()) return false
        _isLoggedIn.value = true
        return true
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    fun alternarFavorito(filmeId: Int) {
        val atual = _favoritos.value.toMutableSet()

        if (filmeId in atual) {
            atual.remove(filmeId)
        } else {
            atual.add(filmeId)
        }

        _favoritos.value = atual
    }

    fun buscarFilme(id: Int): Filme? {
        return _filmes.value.find { it.id == id }
    }
}
