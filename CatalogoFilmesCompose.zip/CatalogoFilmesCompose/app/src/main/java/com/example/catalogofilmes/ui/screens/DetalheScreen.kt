package com.example.catalogofilmes.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.catalogofilmes.viewmodel.FilmesViewModel

@Composable
fun DetalheScreen(
    filmeId: Int,
    viewModel: FilmesViewModel,
    onVoltar: () -> Unit
) {
    val filmes by viewModel.filmes.collectAsState()
    val favoritos by viewModel.favoritos.collectAsState()

    val filme = filmes.find { it.id == filmeId }

    if (filme == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            IconButton(onClick = onVoltar) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Voltar"
                )
            }

            Text("Filme não encontrado.")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconButton(onClick = onVoltar) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Voltar"
            )
        }

        Text(
            text = filme.titulo,
            style = MaterialTheme.typography.headlineLarge
        )

        Text("Gênero: ${filme.genero}")
        Text("Ano: ${filme.ano}")
        Text("Nota: ${filme.nota}")
        Text(filme.descricao)

        IconButton(
            onClick = { viewModel.alternarFavorito(filme.id) }
        ) {
            Icon(
                imageVector = if (filme.id in favoritos) {
                    Icons.Default.Favorite
                } else {
                    Icons.Default.FavoriteBorder
                },
                contentDescription = if (filme.id in favoritos) {
                    "Remover dos favoritos"
                } else {
                    "Adicionar aos favoritos"
                }
            )
        }
    }
}
