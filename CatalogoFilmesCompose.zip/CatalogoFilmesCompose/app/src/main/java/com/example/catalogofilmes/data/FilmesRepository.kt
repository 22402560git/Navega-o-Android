package com.example.catalogofilmes.data

object FilmesRepository {

    fun listarFilmes(): List<Filme> = listOf(
        Filme(
            1,
            "A Jornada",
            "Aventura",
            2024,
            8.7,
            "Uma aventura sobre amizade, coragem e descobertas em uma longa viagem."
        ),
        Filme(
            2,
            "Código do Futuro",
            "Ficção",
            2023,
            8.4,
            "Um grupo de jovens tenta resolver um mistério tecnológico que pode mudar o futuro."
        ),
        Filme(
            3,
            "Além das Estrelas",
            "Ficção",
            2025,
            9.0,
            "Uma equipe explora novos horizontes e precisa trabalhar unida diante do desconhecido."
        ),
        Filme(
            4,
            "O Último Verão",
            "Drama",
            2022,
            8.1,
            "Uma história sobre escolhas, amizade e novas fases da vida."
        ),
        Filme(
            5,
            "Cidade em Movimento",
            "Comédia",
            2024,
            7.9,
            "Uma comédia leve sobre situações inesperadas que acontecem durante um dia agitado."
        ),
        Filme(
            6,
            "Mistério no Museu",
            "Mistério",
            2021,
            8.6,
            "Objetos desaparecem misteriosamente e uma investigação começa dentro do museu."
        )
    )
}
