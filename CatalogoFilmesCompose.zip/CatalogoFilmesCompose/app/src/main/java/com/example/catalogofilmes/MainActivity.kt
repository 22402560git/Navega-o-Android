package com.example.catalogofilmes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.catalogofilmes.ui.theme.CatalogoFilmesTheme
import com.example.catalogofilmes.ui.navigation.AppNavigation
import com.example.catalogofilmes.viewmodel.FilmesViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FilmesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CatalogoFilmesTheme {
                AppNavigation(viewModel = viewModel)
            }
        }
    }
}
