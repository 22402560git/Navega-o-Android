package com.example.catalogofilmes.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val AppLightColors = lightColorScheme(
    primary = AzulPrincipal,
    secondary = AzulClaro,
    tertiary = Destaque,
    background = FundoClaro,
    onBackground = TextoEscuro
)

@Composable
fun CatalogoFilmesTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppLightColors,
        typography = AppTypography,
        content = content
    )
}
