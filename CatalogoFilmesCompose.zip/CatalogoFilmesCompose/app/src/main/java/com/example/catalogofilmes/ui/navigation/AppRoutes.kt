package com.example.catalogofilmes.ui.navigation

import kotlinx.serialization.Serializable

sealed interface AppRoute

@Serializable
data object Splash : AppRoute

@Serializable
data object Login : AppRoute

@Serializable
data object Main : AppRoute

@Serializable
data object Filmes : AppRoute

@Serializable
data object Favoritos : AppRoute

@Serializable
data object Perfil : AppRoute

@Serializable
data class Detalhe(val filmeId: Int) : AppRoute
