package com.example.catalogofilmes.ui.components

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import com.example.catalogofilmes.ui.navigation.AppRoute
import com.example.catalogofilmes.ui.navigation.BottomTab
import com.example.catalogofilmes.ui.navigation.Favoritos
import com.example.catalogofilmes.ui.navigation.Filmes
import com.example.catalogofilmes.ui.navigation.Perfil

@Composable
fun AppBottomBar(
    abas: List<BottomTab>,
    destinoAtual: NavDestination?,
    onTabClick: (AppRoute) -> Unit
) {
    NavigationBar {
        abas.forEach { aba ->
            val selecionada = when (aba.route) {
                Filmes -> destinoAtual?.hasRoute<Filmes>() == true
                Favoritos -> destinoAtual?.hasRoute<Favoritos>() == true
                Perfil -> destinoAtual?.hasRoute<Perfil>() == true
                else -> false
            }

            NavigationBarItem(
                selected = selecionada,
                onClick = { onTabClick(aba.route) },
                icon = {
                    Icon(
                        imageVector = aba.icon,
                        contentDescription = aba.titulo
                    )
                },
                label = { Text(aba.titulo) }
            )
        }
    }
}
