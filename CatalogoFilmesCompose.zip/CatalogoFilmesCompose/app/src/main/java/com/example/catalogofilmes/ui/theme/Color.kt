package com.example.catalogofilmes.ui.theme

import androidx.compose.ui.graphics.Color

val AzulPrincipal = Color(0xFF173F5F)
val AzulClaro = Color(0xFF4F86A8)
val FundoClaro = Color(0xFFF4F7FA)
val TextoEscuro = Color(0xFF17212B)
val Destaque = Color(0xFFF2A900)
